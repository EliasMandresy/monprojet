import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.Date;

public class PizzasClient extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        PrintWriter out = res.getWriter();

        ServletContext context = this.getServletContext();
        String pizza_spec = (String) context.getAttribute("Specialite");
        Date day = (Date) context.getAttribute("Date");
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        String today = df.format(day);
        out.println("Aujourd'hui (" + today + "), notre specialite est : " + pizza_spec);
    }
}