import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.Date;


public class PizzasAdmin extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/plain");
        PrintWriter out = res.getWriter();
        ServletContext context = this.getServletContext();
        context.setAttribute("Specialite", "4 fromages");
        context.setAttribute("Date", new Date());
        out.println("La pizza du jour a été définie.");
    }
}