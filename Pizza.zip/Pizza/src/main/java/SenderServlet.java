import java.io.IOException;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class SenderServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.setAttribute("seconde", "au revoir");
        RequestDispatcher dispat = req.getRequestDispatcher("/recepteur.html?mot=bonjour");
        dispat.forward(req, res);
        // Ne rien faire sur req et res Le chemin est absolu par
    }
}